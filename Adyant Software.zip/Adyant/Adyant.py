from PyQt5 import QtCore, QtGui, QtWidgets, QtTest
from PyQt5.QtWidgets import QListWidgetItem, QMessageBox
import simpleaudio as sa
from indic_transliteration import sanscript
from indic_transliteration.sanscript import transliterate
import webbrowser
import csv
import os


def click_sound():
    wave_obj = sa.WaveObject.from_wave_file(r"Sounds/clickon.wav")
    wave_obj.play()


class Ui_MainWindow(object):

    def __init__(self):
        self.user = ""
        self.user_dp = "Images/profile.png"
        self.prev = 0
        self.ham = 0
        self.cur = 0
        self.novice_question_number = 0
        self.score_num = 0
        self.website = "https://stellarcontrivers.github.io/Adyant/"

        self.question_data = []
        with open(r"Data/Questions/novice_alphabet.csv", 'r') as sd:
            reader = csv.reader(sd)
            for row in reader:
                self.question_data.append(row)

    def setupUi(self, MainWindow):
        # ==========================================================================================================================
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1920, 1080)
        MainWindow.showFullScreen()
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.background1 = QtWidgets.QLabel(self.centralwidget)
        self.background1.setGeometry(QtCore.QRect(0, 0, 1920, 1080))
        self.background1.setText("")
        self.background1.setPixmap(QtGui.QPixmap("Images/Backgrounds/ca0f73521b2f7d55ba082120614ad807.jpg"))
        self.background1.setScaledContents(True)
        self.background1.setObjectName("background1")

        self.background2 = QtWidgets.QLabel(self.centralwidget)
        self.background2.setGeometry(QtCore.QRect(0, 0, 1920, 1080))
        self.background2.setText("")
        self.background2.setPixmap(QtGui.QPixmap("Images/Backgrounds/background1 (2).jpg"))
        self.background2.setScaledContents(True)
        self.background2.setObjectName("background1")
        self.logo = QtWidgets.QLabel(self.centralwidget)
        self.logo.setGeometry(QtCore.QRect(640, 150, 670, 271))
        self.logo.setText("")
        self.logo.setPixmap(QtGui.QPixmap("Images/logo.png"))
        self.logo.setScaledContents(True)
        self.logo.setObjectName("logo")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(960, 90, 55, 16))
        self.label_2.setObjectName("label_2")
        self.signin = QtWidgets.QPushButton(self.centralwidget)
        self.signin.setGeometry(QtCore.QRect(750, 510, 451, 61))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(17)
        self.signin.setFont(font)
        self.signin.setStyleSheet("background-color:rgb(248, 193, 96);\n"
                                  "border-style: outset;\n"
                                  "border-width: 2px;\n"
                                  "border-radius: 25px;\n"
                                  "border-color:rgb(248, 193, 96);\n"
                                  "padding: 4px;")
        self.signin.setObjectName("signin")
        self.signup = QtWidgets.QPushButton(self.centralwidget)
        self.signup.setGeometry(QtCore.QRect(750, 620, 451, 61))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(17)
        self.signup.setFont(font)
        self.signup.setStyleSheet("background-color:rgb(248, 193, 96);\n"
                                  "border-style: outset;\n"
                                  "border-width: 2px;\n"
                                  "border-radius: 25px;\n"
                                  "border-color:rgb(248, 193, 96);\n"
                                  "padding: 4px;")
        self.signup.setObjectName("signup")
        self.signtext = QtWidgets.QLineEdit(self.centralwidget)
        self.signtext.setGeometry(QtCore.QRect(757, 517, 440, 50))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(12)
        font.setBold(False)
        font.setWeight(50)
        self.signtext.setFont(font)
        self.signtext.setStyleSheet("background-color:white;\n"
                                    "border-style: outset;\n"
                                    "border-width: 2px;\n"
                                    "border-radius: 25px;\n"
                                    "border-color:rgb(248, 193, 96);\n"
                                    "padding: 4px;")
        self.signtext.setAlignment(QtCore.Qt.AlignCenter)
        self.signtext.setObjectName("signtext")
        # ==========================================================================================================================
        self.signupback = QtWidgets.QLabel(self.centralwidget)
        self.signupback.setGeometry(QtCore.QRect(0, 0, 1920, 1080))
        self.signupback.setText("")
        self.signupback.setPixmap(QtGui.QPixmap("Images/Backgrounds/newlogin.jpg"))
        self.signupback.setScaledContents(True)
        self.signupback.setObjectName("signupback")
        self.baba = QtWidgets.QLabel(self.centralwidget)
        self.baba.setGeometry(QtCore.QRect(260, 220, 601, 611))
        self.baba.setText("")
        self.baba.setPixmap(QtGui.QPixmap("Images/baba.png"))
        self.baba.setScaledContents(True)
        self.baba.setObjectName("baba")
        self.intermediate = QtWidgets.QPushButton(self.centralwidget)
        self.intermediate.setGeometry(QtCore.QRect(1120, 500, 411, 81))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(15)
        font.setBold(True)
        font.setWeight(75)
        self.intermediate.setFont(font)
        self.intermediate.setStyleSheet("background-color: rgb(252, 255, 26);\n"
                                        "border-style: outset;\n"
                                        "border-width: 3px;\n"
                                        "border-radius: 25px;\n"
                                        "border-color:  rgb(231, 193, 0);\n"
                                        "padding: 4px;")
        self.intermediate.setObjectName("intermediate")
        self.beginner = QtWidgets.QPushButton(self.centralwidget)
        self.beginner.setGeometry(QtCore.QRect(1120, 650, 411, 81))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(15)
        font.setBold(True)
        font.setWeight(75)
        self.beginner.setFont(font)
        self.beginner.setStyleSheet("background-color: rgb(252, 255, 26);\n"
                                    "border-style: outset;\n"
                                    "border-width: 3px;\n"
                                    "border-radius: 25px;\n"
                                    "border-color:  rgb(231, 193, 0);\n"
                                    "padding: 4px;")
        self.beginner.setObjectName("beginner")
        self.novice = QtWidgets.QPushButton(self.centralwidget)
        self.novice.setGeometry(QtCore.QRect(1120, 360, 411, 81))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(15)
        font.setBold(True)
        font.setWeight(75)
        self.novice.setFont(font)
        self.novice.setStyleSheet("background-color: rgb(252, 255, 26);\n"
                                  "border-style: outset;\n"
                                  "border-width: 3px;\n"
                                  "border-radius: 25px;\n"
                                  "border-color:  rgb(231, 193, 0);\n"
                                  "padding: 4px;")
        self.novice.setObjectName("novice")
        # ==========================================================================================================================

        MainWindow.setCentralWidget(self.centralwidget)

        self.background1.raise_()
        self.logo.raise_()
        wave_obj = sa.WaveObject.from_wave_file(r"Sounds/intro.wav")
        wave_obj.play()
        self.ani_fade(self.logo, 1000)

        self.signup.raise_()
        self.signin.raise_()

        self.signin.clicked.connect(self.sigin_function_1)
        self.signup.clicked.connect(self.signup_)

        # ================================================================================================================

        self.mainback = QtWidgets.QLabel(self.centralwidget)
        self.mainback.setGeometry(QtCore.QRect(0, 0, 1920, 1080))
        self.mainback.setStyleSheet("background-color: rgb(229, 228, 223);")
        self.mainback.setText("")
        self.mainback.setScaledContents(False)
        self.mainback.setObjectName("mainback")
        self.header = QtWidgets.QLabel(self.centralwidget)
        self.header.setGeometry(QtCore.QRect(0, 0, 1980, 111))
        self.header.setStyleSheet("background-color: rgb(191, 190, 187);")
        self.header.setText("")
        self.header.setObjectName("header")
        self.header_shadow = QtWidgets.QLabel(self.centralwidget)
        self.header_shadow.setGeometry(QtCore.QRect(0, 10, 1980, 111))
        self.header_shadow.setStyleSheet("background-color: rgb(172, 171, 169);")
        self.header_shadow.setText("")
        self.header_shadow.setObjectName("header_shadow")
        self.footer_shadow = QtWidgets.QLabel(self.centralwidget)
        self.footer_shadow.setGeometry(QtCore.QRect(0, 970, 1980, 111))
        self.footer_shadow.setStyleSheet("background-color: rgb(172, 171, 169);")
        self.footer_shadow.setText("")
        self.footer_shadow.setObjectName("footer_shadow")
        self.footer = QtWidgets.QLabel(self.centralwidget)
        self.footer.setGeometry(QtCore.QRect(0, 980, 1980, 111))
        self.footer.setStyleSheet("background-color: rgb(191, 190, 187);file:///D:/Adyant/Data/Checkpoints/bro.csv")
        self.footer.setText("")
        self.footer.setObjectName("footer")
        self.profile = QtWidgets.QLabel(self.centralwidget)
        self.profile.setGeometry(QtCore.QRect(1811, 17, 80, 80))
        self.profile.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.profile.setFrameShadow(QtWidgets.QFrame.Raised)
        self.profile.setText("")
        self.profile.setPixmap(QtGui.QPixmap("Images/profile.png"))
        self.profile.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.profile.setScaledContents(True)
        self.profile.setObjectName("profile")
        self.profile_shadow = QtWidgets.QLabel(self.centralwidget)
        self.profile_shadow.setGeometry(QtCore.QRect(1814, 22, 80, 80))
        self.profile_shadow.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.profile_shadow.setFrameShadow(QtWidgets.QFrame.Raised)
        self.profile_shadow.setText("")
        self.profile_shadow.setPixmap(QtGui.QPixmap("Images/profile_shadow.png"))
        self.profile_shadow.setScaledContents(True)
        self.profile_shadow.setObjectName("profile_shadow")
        self.hamburger = QtWidgets.QLabel(self.centralwidget)
        self.hamburger.setGeometry(QtCore.QRect(25, 27, 60, 60))
        self.hamburger.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.hamburger.setFrameShadow(QtWidgets.QFrame.Raised)
        self.hamburger.setText("")
        self.hamburger.setPixmap(QtGui.QPixmap("Images/hamburger.png"))
        self.hamburger.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.hamburger.setScaledContents(True)
        self.hamburger.setObjectName("hamburger")
        self.logo_2 = QtWidgets.QLabel(self.centralwidget)
        self.logo_2.setGeometry(QtCore.QRect(791, 13, 351, 131))
        self.logo_2.setText("")
        self.logo_2.setPixmap(QtGui.QPixmap("Images/logo.png"))
        self.logo_2.setScaledContents(True)
        self.logo_2.setObjectName("logo_2")
        self.header_2 = QtWidgets.QLabel(self.centralwidget)
        self.header_2.setGeometry(QtCore.QRect(730, 80, 461, 81))
        self.header_2.setStyleSheet("background-color: rgb(191, 190, 187);\n"
                                    "border-radius: 20px;")
        self.header_2.setText("")
        self.header_2.setObjectName("header_2")
        self.header_2_shadow = QtWidgets.QLabel(self.centralwidget)
        self.header_2_shadow.setGeometry(QtCore.QRect(740, 90, 461, 81))
        self.header_2_shadow.setStyleSheet("background-color: rgb(172, 171, 169);\n"
                                           "border-radius: 20px;")
        self.header_2_shadow.setText("")
        self.header_2_shadow.setObjectName("header_2_shadow")
        self.hamwin = QtWidgets.QLabel(self.centralwidget)
        self.hamwin.setGeometry(QtCore.QRect(0, 90, 431, 921))
        self.hamwin.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.hamwin.setStyleSheet("background-color: rgb(0, 170, 255);")
        self.hamwin.setText("")
        self.hamwin.setObjectName("hamwin")
        self.shadow = QtWidgets.QLabel(self.centralwidget)
        self.shadow.setGeometry(QtCore.QRect(0, 0, 1920, 1080))
        self.shadow.setStyleSheet("")
        self.shadow.setText("")
        self.shadow.setPixmap(QtGui.QPixmap("Images/shadow.png"))
        self.shadow.setScaledContents(True)
        self.shadow.setObjectName("shadow")
        self.hamwin_shadow = QtWidgets.QLabel(self.centralwidget)
        self.hamwin_shadow.setGeometry(QtCore.QRect(12, 20, 431, 991))
        self.hamwin_shadow.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.hamwin_shadow.setStyleSheet("background-color: rgb(0, 151, 227);")
        self.hamwin_shadow.setText("")
        self.hamwin_shadow.setObjectName("hamwin_shadow")
        self.hanburger_window = QtWidgets.QWidget(self.centralwidget)
        self.hanburger_window.setGeometry(QtCore.QRect(10, 130, 411, 831))
        self.hanburger_window.setObjectName("hanburger_window")
        self.profile_shadow_2 = QtWidgets.QLabel(self.hanburger_window)
        self.profile_shadow_2.setGeometry(QtCore.QRect(23, 25, 80, 80))
        self.profile_shadow_2.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.profile_shadow_2.setFrameShadow(QtWidgets.QFrame.Raised)
        self.profile_shadow_2.setText("")
        self.profile_shadow_2.setPixmap(QtGui.QPixmap("Images/profile_shadow.png"))
        self.profile_shadow_2.setScaledContents(True)
        self.profile_shadow_2.setObjectName("profile_shadow_2")
        self.profile_2 = QtWidgets.QLabel(self.hanburger_window)
        self.profile_2.setGeometry(QtCore.QRect(20, 20, 80, 80))
        self.profile_2.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.profile_2.setFrameShadow(QtWidgets.QFrame.Raised)
        self.profile_2.setText("")
        self.profile_2.setPixmap(QtGui.QPixmap("Images/profile.png"))
        self.profile_2.setScaledContents(True)
        self.profile_2.setObjectName("profile_2")
        self.welcome = QtWidgets.QLabel(self.hanburger_window)
        self.welcome.setGeometry(QtCore.QRect(120, 7, 181, 51))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(20)
        self.welcome.setFont(font)
        self.welcome.setStyleSheet("")
        self.welcome.setObjectName("welcome")
        self.Username = QtWidgets.QLabel(self.hanburger_window)
        self.Username.setGeometry(QtCore.QRect(120, 60, 181, 31))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(20)
        self.Username.setFont(font)
        self.Username.setStyleSheet("")
        self.Username.setObjectName("Username")
        self.ham_novice = QtWidgets.QPushButton(self.hanburger_window)
        self.ham_novice.setGeometry(QtCore.QRect(50, 155, 291, 61))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(18)
        font.setBold(False)
        font.setWeight(50)
        self.ham_novice.setFont(font)
        self.ham_novice.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.ham_novice.setStyleSheet("background-color: rgb(0, 165, 248);\n"
                                      "border-style: initial;\n"
                                      "border-width: 1px;\n"
                                      "border-radius: 15px;\n"
                                      "border-color:  rgb(0, 151, 227);\n"
                                      "padding: 4px;\n"
                                      "text-align: left;\n"
                                      "color:white;")
        self.ham_novice.setFlat(False)
        self.ham_novice.setObjectName("ham_novice")
        self.ham_beg = QtWidgets.QPushButton(self.hanburger_window)
        self.ham_beg.setGeometry(QtCore.QRect(50, 255, 291, 61))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(18)
        font.setBold(False)
        font.setWeight(50)
        self.ham_beg.setFont(font)
        self.ham_beg.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.ham_beg.setStyleSheet("background-color: rgb(0, 165, 248);\n"
                                   "border-style: initial;\n"
                                   "border-width: 1px;\n"
                                   "border-radius: 15px;\n"
                                   "border-color:  rgb(0, 151, 227);\n"
                                   "padding: 4px;\n"
                                   "text-align: left;\n"
                                   "color:white;")
        self.ham_beg.setFlat(False)
        self.ham_beg.setObjectName("ham_beg")
        self.ham_int = QtWidgets.QPushButton(self.hanburger_window)
        self.ham_int.setGeometry(QtCore.QRect(50, 355, 291, 61))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(18)
        font.setBold(False)
        font.setWeight(50)
        self.ham_int.setFont(font)
        self.ham_int.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.ham_int.setStyleSheet("background-color: rgb(0, 165, 248);\n"
                                   "border-style: initial;\n"
                                   "border-width: 1px;\n"
                                   "border-radius: 15px;\n"
                                   "border-color:  rgb(0, 151, 227);\n"
                                   "padding: 4px;\n"
                                   "text-align: left;\n"
                                   "color:white;")
        self.ham_int.setFlat(False)
        self.ham_int.setObjectName("ham_int")
        self.ham_shop = QtWidgets.QPushButton(self.hanburger_window)
        self.ham_shop.setGeometry(QtCore.QRect(50, 451, 291, 61))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(18)
        font.setBold(False)
        font.setWeight(50)
        self.ham_shop.setFont(font)
        self.ham_shop.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.ham_shop.setStyleSheet("background-color: rgb(0, 165, 248);\n"
                                    "border-style: initial;\n"
                                    "border-width: 1px;\n"
                                    "border-radius: 15px;\n"
                                    "border-color:  rgb(0, 151, 227);\n"
                                    "padding: 4px;\n"
                                    "text-align: left;\n"
                                    "color:white;")
        self.ham_shop.setFlat(False)
        self.ham_shop.setObjectName("ham_shop")
        self.ham_about = QtWidgets.QPushButton(self.hanburger_window)
        self.ham_about.setGeometry(QtCore.QRect(50, 551, 291, 61))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(18)
        font.setBold(False)
        font.setWeight(50)
        self.ham_about.setFont(font)
        self.ham_about.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.ham_about.setStyleSheet("background-color: rgb(0, 165, 248);\n"
                                     "border-style: initial;\n"
                                     "border-width: 1px;\n"
                                     "border-radius: 15px;\n"
                                     "border-color:  rgb(0, 151, 227);\n"
                                     "padding: 4px;\n"
                                     "text-align: left;\n"
                                     "color:white;")
        self.ham_about.setFlat(False)
        self.ham_about.setObjectName("ham_about")
        self.ham_out = QtWidgets.QPushButton(self.hanburger_window)
        self.ham_out.setGeometry(QtCore.QRect(50, 651, 291, 61))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(18)
        font.setBold(False)
        font.setWeight(50)
        self.ham_out.setFont(font)
        self.ham_out.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.ham_out.setStyleSheet("background-color: rgb(0, 165, 248);\n"
                                   "border-style: initial;\n"
                                   "border-width: 1px;\n"
                                   "border-radius: 15px;\n"
                                   "border-color:  rgb(0, 151, 227);\n"
                                   "padding: 4px;\n"
                                   "text-align: left;\n"
                                   "color:white;")
        self.ham_out.setFlat(False)
        self.ham_out.setObjectName("ham_out")
        self.ham_close = QtWidgets.QPushButton(self.hanburger_window)
        self.ham_close.setGeometry(QtCore.QRect(50, 744, 291, 61))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(18)
        font.setBold(False)
        font.setWeight(50)
        self.ham_close.setFont(font)
        self.ham_close.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        # rgb(255,0,0)
        self.ham_close.setStyleSheet("background-color: rgb(0, 165, 248);\n"
                                     "border-style: initial;\n"
                                     "border-width: 1px;\n"
                                     "border-radius: 15px;\n"
                                     "border-color:  rgb(0, 151, 227);\n"
                                     "padding: 4px;\n"
                                     "text-align: left;\n"
                                     "color:white;")
        self.ham_close.setFlat(False)
        self.ham_close.setObjectName("ham_close")
        self.profile_shadow_2.raise_()
        self.welcome.raise_()
        self.Username.raise_()
        self.ham_novice.raise_()
        self.ham_beg.raise_()
        self.ham_int.raise_()
        self.ham_shop.raise_()
        self.ham_about.raise_()
        self.ham_out.raise_()
        self.profile_2.raise_()
        self.ham_close.raise_()

        self.novice_questions = QtWidgets.QWidget(self.centralwidget)
        self.novice_questions.setGeometry(QtCore.QRect(280, 200, 1331, 701))
        self.novice_questions.setObjectName("novice_questions")
        self.letter = QtWidgets.QLabel(self.novice_questions)
        self.letter.setGeometry(QtCore.QRect(113, 64, 321, 291))
        font = QtGui.QFont()
        font.setPointSize(130)
        self.letter.setFont(font)
        self.letter.setStyleSheet("background-color: rgb(204, 136, 0);\n"
                                  "color: white;\n"
                                  "border-radius: 40px;")
        self.letter.setAlignment(QtCore.Qt.AlignCenter)
        self.letter.setObjectName("letter")
        self.letter_shadow = QtWidgets.QLabel(self.novice_questions)
        self.letter_shadow.setGeometry(QtCore.QRect(119, 71, 321, 291))
        font = QtGui.QFont()
        font.setPointSize(130)
        self.letter_shadow.setFont(font)
        self.letter_shadow.setStyleSheet("background-color: rgb(161, 107, 0);\n"
                                         "color: white;\n"
                                         "border-radius: 40px;")
        self.letter_shadow.setText("")
        self.letter_shadow.setAlignment(QtCore.Qt.AlignCenter)
        self.letter_shadow.setObjectName("letter_shadow")
        self.pronontiation_shadow = QtWidgets.QLabel(self.novice_questions)
        self.pronontiation_shadow.setGeometry(QtCore.QRect(117, 387, 321, 81))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.pronontiation_shadow.setFont(font)
        self.pronontiation_shadow.setStyleSheet("background-color:rgb(86, 172, 0);\n"
                                                "color: white;\n"
                                                "border-radius: 30px;\n"
                                                "")
        self.pronontiation_shadow.setText("")
        self.pronontiation_shadow.setAlignment(QtCore.Qt.AlignCenter)
        self.pronontiation_shadow.setObjectName("pronontiation_shadow")
        self.label = QtWidgets.QLabel(self.novice_questions)
        self.label.setGeometry(QtCore.QRect(510, 54, 641, 81))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(20)
        self.label.setFont(font)
        self.label.setStyleSheet("\n"
                                 "")
        self.label.setObjectName("label")
        self.option3 = QtWidgets.QLabel(self.novice_questions)
        self.option3.setGeometry(QtCore.QRect(520, 310, 250, 130))
        self.option3.setStyleSheet("background-color:rgb(85, 255, 0);\n"
                                   "border-radius: 25px;")
        self.option3.setText("")
        self.option3.setObjectName("option3")
        self.option1 = QtWidgets.QLabel(self.novice_questions)
        self.option1.setGeometry(QtCore.QRect(520, 150, 250, 130))
        self.option1.setStyleSheet("background-color:rgb(85, 255, 0);\n"
                                   "border-radius: 25px;")
        self.option1.setText("")
        self.option1.setObjectName("option1")
        self.option4 = QtWidgets.QLabel(self.novice_questions)
        self.option4.setGeometry(QtCore.QRect(800, 310, 250, 130))
        self.option4.setStyleSheet("background-color:rgb(85, 255, 0);\n"
                                   "border-radius: 25px;")
        self.option4.setText("")
        self.option4.setObjectName("option4")
        self.option2 = QtWidgets.QLabel(self.novice_questions)
        self.option2.setGeometry(QtCore.QRect(800, 150, 250, 130))
        self.option2.setStyleSheet("background-color:rgb(85, 255, 0);\n"
                                   "border-radius: 25px;")
        self.option2.setText("")
        self.option2.setObjectName("option2")
        self.option2_shadow = QtWidgets.QLabel(self.novice_questions)
        self.option2_shadow.setGeometry(QtCore.QRect(806, 157, 250, 130))
        self.option2_shadow.setStyleSheet("background-color:rgb(66, 199, 0);\n"
                                          "border-radius: 25px;")
        self.option2_shadow.setText("")
        self.option2_shadow.setObjectName("option2_shadow")
        self.option4_shadow = QtWidgets.QLabel(self.novice_questions)
        self.option4_shadow.setGeometry(QtCore.QRect(806, 317, 250, 130))
        self.option4_shadow.setStyleSheet("background-color:rgb(66, 199, 0);\n"
                                          "border-radius: 25px;")
        self.option4_shadow.setText("")
        self.option4_shadow.setObjectName("option4_shadow")
        self.option3_shadow = QtWidgets.QLabel(self.novice_questions)
        self.option3_shadow.setGeometry(QtCore.QRect(526, 317, 250, 130))
        self.option3_shadow.setStyleSheet("background-color:rgb(66, 199, 0);\n"
                                          "border-radius: 25px;")
        self.option3_shadow.setText("")
        self.option3_shadow.setObjectName("option3_shadow")
        self.option1_shadow = QtWidgets.QLabel(self.novice_questions)
        self.option1_shadow.setGeometry(QtCore.QRect(526, 157, 250, 130))
        self.option1_shadow.setStyleSheet("background-color:rgb(66, 199, 0);\n"
                                          "border-radius: 25px;")
        self.option1_shadow.setText("")
        self.option1_shadow.setObjectName("option1_shadow")
        self.opt1_rad = QtWidgets.QRadioButton(self.novice_questions)
        self.opt1_rad.setGeometry(QtCore.QRect(550, 159, 201, 111))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(25)
        font.setBold(True)
        font.setWeight(75)
        self.opt1_rad.setFont(font)
        self.opt1_rad.setStyleSheet("color: white;")
        self.opt1_rad.setObjectName("opt1_rad")
        self.opt2_rad = QtWidgets.QRadioButton(self.novice_questions)
        self.opt2_rad.setGeometry(QtCore.QRect(840, 160, 201, 111))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(25)
        font.setBold(True)
        font.setWeight(75)
        self.opt2_rad.setFont(font)
        self.opt2_rad.setStyleSheet("color: white;")
        self.opt2_rad.setObjectName("opt2_rad")
        self.opt3_rad = QtWidgets.QRadioButton(self.novice_questions)
        self.opt3_rad.setGeometry(QtCore.QRect(550, 320, 211, 111))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(25)
        font.setBold(True)
        font.setWeight(75)
        self.opt3_rad.setFont(font)
        self.opt3_rad.setStyleSheet("color: white;")
        self.opt3_rad.setObjectName("opt3_rad")
        self.opt4_rad = QtWidgets.QRadioButton(self.novice_questions)
        self.opt4_rad.setGeometry(QtCore.QRect(840, 320, 201, 111))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(25)
        font.setBold(True)
        font.setWeight(75)
        self.opt4_rad.setFont(font)
        self.opt4_rad.setStyleSheet("color: white;")
        self.opt4_rad.setObjectName("opt4_rad")
        self.option3_3 = QtWidgets.QLabel(self.novice_questions)
        self.option3_3.setGeometry(QtCore.QRect(120, 559, 981, 91))
        self.option3_3.setStyleSheet("background-color:rgb(0, 142, 213);\n"
                                     "border-radius: 25px;")
        self.option3_3.setText("")
        self.option3_3.setObjectName("option3_3")
        self.novice_check = QtWidgets.QPushButton(self.novice_questions)
        self.novice_check.setGeometry(QtCore.QRect(113, 550, 981, 91))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(20)
        self.novice_check.setFont(font)
        self.novice_check.setStyleSheet("background-color:rgb(0, 170, 255);\n"
                                        "border-radius: 25px;\n"
                                        "color:white;")
        self.novice_check.setObjectName("novice_check")
        self.novice_sound = QtWidgets.QPushButton(self.novice_questions)
        self.novice_sound.setGeometry(QtCore.QRect(111, 381, 321, 81))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(20)
        font.setBold(False)
        font.setWeight(50)
        self.novice_sound.setFont(font)
        self.novice_sound.setStyleSheet("background-color: rgb(107, 214, 0);\n"
                                        "color: white;\n"
                                        "border-radius: 30px;\n"
                                        "")
        self.novice_sound.setObjectName("novice_sound")
        self.letter_shadow.raise_()
        self.letter.raise_()
        self.pronontiation_shadow.raise_()
        self.label.raise_()
        self.option2_shadow.raise_()
        self.option4_shadow.raise_()
        self.option3_shadow.raise_()
        self.option1_shadow.raise_()
        self.option2.raise_()
        self.option4.raise_()
        self.option1.raise_()
        self.option3.raise_()
        self.opt1_rad.raise_()
        self.opt2_rad.raise_()
        self.opt3_rad.raise_()
        self.opt4_rad.raise_()
        self.option3_3.raise_()
        self.novice_check.raise_()
        self.novice_sound.raise_()

        self.label_novice = QtWidgets.QLabel(self.centralwidget)
        self.label_novice.setGeometry(QtCore.QRect(1828, 230, 261, 641))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(20)
        self.label_novice.setFont(font)
        self.label_novice.setStyleSheet("background-color: rgb(251, 195, 4);\n"
                                        "border-style: initial;\n"
                                        "border-width: 2px;\n"
                                        "border-radius: 30px;\n"
                                        "border-color: rgb(251, 195, 4);\n"
                                        "padding: 4px;\n"
                                        "color: white;")
        self.label_novice.setText("")
        self.label_novice.setAlignment(QtCore.Qt.AlignCenter)
        self.label_novice.setObjectName("label_novice")
        self.label_shadow = QtWidgets.QLabel(self.centralwidget)
        self.label_shadow.setGeometry(QtCore.QRect(1820, 240, 271, 641))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(20)
        self.label_shadow.setFont(font)
        self.label_shadow.setStyleSheet("background-color: rgb(163, 162, 161);\n"
                                        "border-style: initial;\n"
                                        "border-width: 2px;\n"
                                        "border-radius: 30px;\n"
                                        "border-color: rgb(251, 195, 4);\n"
                                        "padding: 4px;\n"
                                        "color: white;")
        self.label_shadow.setAlignment(QtCore.Qt.AlignCenter)
        self.label_shadow.setObjectName("label_shadow")
        self.level_text_novice = QtWidgets.QLabel(self.centralwidget)
        self.level_text_novice.setGeometry(QtCore.QRect(1850, 263, 50, 591))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setBold(True)
        font.setPointSize(20)
        self.level_text_novice.setFont(font)
        self.level_text_novice.setAlignment(QtCore.Qt.AlignCenter)
        self.level_text_novice.setObjectName("level_text_novice")
        self.level_text_novice.setStyleSheet("color:white;")
        self.level_text_beginner = QtWidgets.QLabel(self.centralwidget)
        self.level_text_beginner.setGeometry(QtCore.QRect(1850, 263, 50, 591))
        self.level_text_beginner.setFont(font)
        self.level_text_beginner.setAlignment(QtCore.Qt.AlignCenter)
        self.level_text_beginner.setObjectName("level_text_beginner")
        self.level_text_beginner.setStyleSheet("color:white;")
        self.level_text_intermediate = QtWidgets.QLabel(self.centralwidget)
        self.level_text_intermediate.setGeometry(QtCore.QRect(1850, 263, 50, 591))
        self.level_text_intermediate.setFont(font)
        self.level_text_intermediate.setAlignment(QtCore.Qt.AlignCenter)
        self.level_text_intermediate.setObjectName("level_text_intermediate")
        self.level_text_intermediate.setStyleSheet("color:white;")
        self.subsection_1 = QtWidgets.QWidget(self.centralwidget)
        self.subsection_1.setGeometry(QtCore.QRect(390, 198, 1211, 711))
        self.subsection_1.setObjectName("subsection_1")
        self.level1 = QtWidgets.QLabel(self.subsection_1)
        self.level1.setGeometry(QtCore.QRect(20, 24, 180, 180))
        self.level1.setText("")
        self.level1.setPixmap(QtGui.QPixmap("Images/profile_shadow.png"))
        self.level1.setScaledContents(True)
        self.level1.setObjectName("level1")
        self.level3 = QtWidgets.QLabel(self.subsection_1)
        self.level3.setGeometry(QtCore.QRect(20, 514, 180, 180))
        self.level3.setText("")
        self.level3.setPixmap(QtGui.QPixmap("Images/profile_shadow.png"))
        self.level3.setScaledContents(True)
        self.level3.setObjectName("level3")
        self.level2 = QtWidgets.QLabel(self.subsection_1)
        self.level2.setGeometry(QtCore.QRect(21, 269, 180, 180))
        self.level2.setText("")
        self.level2.setPixmap(QtGui.QPixmap("Images/profile_shadow.png"))
        self.level2.setScaledContents(True)
        self.level2.setObjectName("level2")
        self.line1 = QtWidgets.QLabel(self.subsection_1)
        self.line1.setGeometry(QtCore.QRect(228, 115, 811, 2))
        self.line1.setStyleSheet("background-color:rgb(117, 117, 117) ;\n"
                                 "border: 2px;\n"
                                 "border-radius: 1px;")
        self.line1.setText("")
        self.line1.setObjectName("line1")
        self.line2 = QtWidgets.QLabel(self.subsection_1)
        self.line2.setGeometry(QtCore.QRect(230, 360, 811, 2))
        self.line2.setStyleSheet("background-color:rgb(117, 117, 117) ;\n"
                                 "border: 2px;\n"
                                 "border-radius: 1px;")
        self.line2.setText("")
        self.line2.setObjectName("line2")
        self.line3 = QtWidgets.QLabel(self.subsection_1)
        self.line3.setGeometry(QtCore.QRect(230, 610, 811, 2))
        self.line3.setStyleSheet("background-color:rgb(117, 117, 117) ;\n"
                                 "border: 2px;\n"
                                 "border-radius: 1px;")
        self.line3.setText("")
        self.line3.setObjectName("line3")
        self.progbar1 = QtWidgets.QLabel(self.subsection_1)
        self.progbar1.setGeometry(QtCore.QRect(230, 140, 811, 21))
        self.progbar1.setStyleSheet("background-color: rgb(195, 195, 195) ;")
        self.progbar1.setText("")
        self.progbar1.setObjectName("progbar1")
        self.progbar2 = QtWidgets.QLabel(self.subsection_1)
        self.progbar2.setGeometry(QtCore.QRect(230, 390, 811, 21))
        self.progbar2.setStyleSheet("background-color: rgb(195, 195, 195) ;")
        self.progbar2.setText("")
        self.progbar2.setObjectName("progbar2")
        self.progbar3 = QtWidgets.QLabel(self.subsection_1)
        self.progbar3.setGeometry(QtCore.QRect(230, 640, 811, 21))
        self.progbar3.setStyleSheet("background-color: rgb(195, 195, 195) ;")
        self.progbar3.setText("")
        self.progbar3.setObjectName("progbar3")
        self.prog1_data = QtWidgets.QLabel(self.subsection_1)
        self.prog1_data.setGeometry(QtCore.QRect(230, 140, 31, 21))
        self.prog1_data.setStyleSheet("background-color: rgb(170, 170, 0);")
        self.prog1_data.setText("")
        self.prog1_data.setObjectName("prog1_data")
        self.prog2_data_2 = QtWidgets.QLabel(self.subsection_1)
        self.prog2_data_2.setGeometry(QtCore.QRect(230, 640, 31, 21))
        self.prog2_data_2.setStyleSheet("background-color: rgb(170, 170, 0);")
        self.prog2_data_2.setText("")
        self.prog2_data_2.setObjectName("prog2_data_2")
        self.prog2_data = QtWidgets.QLabel(self.subsection_1)
        self.prog2_data.setGeometry(QtCore.QRect(230, 390, 31, 21))
        self.prog2_data.setStyleSheet("background-color: rgb(170, 170, 0);")
        self.prog2_data.setText("")
        self.prog2_data.setObjectName("prog2_data")
        self.level1_heading = QtWidgets.QLabel(self.subsection_1)
        self.level1_heading.setGeometry(QtCore.QRect(234, 58, 811, 41))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(20)
        self.level1_heading.setFont(font)
        self.level1_heading.setObjectName("level1_heading")
        self.level2_heading = QtWidgets.QLabel(self.subsection_1)
        self.level2_heading.setGeometry(QtCore.QRect(234, 303, 811, 41))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(20)
        self.level2_heading.setFont(font)
        self.level2_heading.setObjectName("level2_heading")
        self.level3_heading = QtWidgets.QLabel(self.subsection_1)
        self.level3_heading.setGeometry(QtCore.QRect(234, 553, 811, 41))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(20)
        self.level3_heading.setFont(font)
        self.level3_heading.setObjectName("level3_heading")
        self.prog1_shadow = QtWidgets.QLabel(self.subsection_1)
        self.prog1_shadow.setGeometry(QtCore.QRect(235, 147, 811, 21))
        self.prog1_shadow.setStyleSheet("background-color: rgb(135, 135, 135);")
        self.prog1_shadow.setText("")
        self.prog1_shadow.setObjectName("prog1_shadow")
        self.prog3_shadow = QtWidgets.QLabel(self.subsection_1)
        self.prog3_shadow.setGeometry(QtCore.QRect(235, 647, 811, 21))
        self.prog3_shadow.setStyleSheet("background-color: rgb(135, 135, 135);")
        self.prog3_shadow.setText("")
        self.prog3_shadow.setObjectName("prog3_shadow")
        self.prog2_shadow = QtWidgets.QLabel(self.subsection_1)
        self.prog2_shadow.setGeometry(QtCore.QRect(235, 397, 811, 21))
        self.prog2_shadow.setStyleSheet("background-color: rgb(135, 135, 135);")
        self.prog2_shadow.setText("")
        self.prog2_shadow.setObjectName("prog2_shadow")
        self.level1_shadow = QtWidgets.QLabel(self.subsection_1)
        self.level1_shadow.setGeometry(QtCore.QRect(24, 31, 180, 180))
        self.level1_shadow.setStyleSheet("background-color:rgb(113, 113, 113);\n"
                                         "border-radius: 90px;")
        self.level1_shadow.setText("")
        self.level1_shadow.setScaledContents(True)
        self.level1_shadow.setObjectName("level1_shadow")
        self.level2_shadow = QtWidgets.QLabel(self.subsection_1)
        self.level2_shadow.setGeometry(QtCore.QRect(25, 276, 180, 180))
        self.level2_shadow.setStyleSheet("background-color:rgb(113, 113, 113);\n"
                                         "border-radius: 90px;")
        self.level2_shadow.setText("")
        self.level2_shadow.setScaledContents(True)
        self.level2_shadow.setObjectName("level2_shadow")
        self.level3_shadow = QtWidgets.QLabel(self.subsection_1)
        self.level3_shadow.setGeometry(QtCore.QRect(24, 521, 180, 180))
        self.level3_shadow.setStyleSheet("background-color:rgb(113, 113, 113);\n"
                                         "border-radius: 90px;")
        self.level3_shadow.setText("")
        self.level3_shadow.setScaledContents(True)
        self.level3_shadow.setObjectName("level3_shadow")
        self.level1_btn = QtWidgets.QLabel(self.subsection_1)
        self.level1_btn.setGeometry(QtCore.QRect(10, 10, 1191, 221))
        self.level1_btn.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.level1_btn.setText("")
        self.level1_btn.setObjectName("level1_btn")
        self.level2_btn = QtWidgets.QLabel(self.subsection_1)
        self.level2_btn.setGeometry(QtCore.QRect(10, 260, 1191, 221))
        self.level2_btn.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.level2_btn.setText("")
        self.level2_btn.setObjectName("level2_btn")
        self.level3_btn = QtWidgets.QLabel(self.subsection_1)
        self.level3_btn.setGeometry(QtCore.QRect(0, 490, 1201, 221))
        self.level3_btn.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.level3_btn.setText("")
        self.level3_btn.setObjectName("level3_btn")
        self.line1.raise_()
        self.line2.raise_()
        self.line3.raise_()
        self.level1_heading.raise_()
        self.level2_heading.raise_()
        self.level3_heading.raise_()
        self.prog1_shadow.raise_()
        self.prog3_shadow.raise_()
        self.prog2_shadow.raise_()
        self.progbar1.raise_()
        self.progbar3.raise_()
        self.progbar2.raise_()
        self.prog2_data.raise_()
        self.prog1_data.raise_()
        self.prog2_data_2.raise_()
        self.level1_shadow.raise_()
        self.level2_shadow.raise_()
        self.level3_shadow.raise_()
        self.level1.raise_()
        self.level3.raise_()
        self.level2.raise_()
        self.level1_btn.raise_()
        self.level2_btn.raise_()
        self.level3_btn.raise_()

        self.level1.setPixmap(QtGui.QPixmap(r"Images/novice/1.png"))
        self.level2.setPixmap(QtGui.QPixmap(r"Images/novice/2.png"))
        self.level3.setPixmap(QtGui.QPixmap(r"Images/novice/3.png"))

        self.profile_clicked = QtWidgets.QWidget(self.centralwidget)
        self.profile_clicked.setGeometry(QtCore.QRect(651, 210, 621, 651))
        self.profile_clicked.setObjectName("profile_clicked")
        self.profile_pic = QtWidgets.QLabel(self.profile_clicked)
        self.profile_pic.setGeometry(QtCore.QRect(99, 43, 100, 100))
        self.profile_pic.setStyleSheet("border-radius: 135px;")
        self.profile_pic.setText("")
        self.profile_pic.setPixmap(QtGui.QPixmap("Images/profile.png"))
        self.profile_pic.setScaledContents(True)
        self.profile_pic.setObjectName("profile_pic")
        self.profile_pic_shadow = QtWidgets.QLabel(self.profile_clicked)
        self.profile_pic_shadow.setGeometry(QtCore.QRect(103, 50, 100, 100))
        self.profile_pic_shadow.setStyleSheet("border-radius: 50px;\n"
                                              "background-color: rgb(0, 121, 177);")
        self.profile_pic_shadow.setText("")
        self.profile_pic_shadow.setScaledContents(True)
        self.profile_pic_shadow.setObjectName("profile_pic_shadow")
        self.prof_win = QtWidgets.QLabel(self.profile_clicked)
        self.prof_win.setGeometry(QtCore.QRect(30, 10, 551, 611))
        self.prof_win.setStyleSheet("background-color: rgb(0, 170, 255);\n"
                                    "border-radius: 50px;")
        self.prof_win.setText("")
        self.prof_win.setObjectName("prof_win")
        self.prof_win_shadow = QtWidgets.QLabel(self.profile_clicked)
        self.prof_win_shadow.setGeometry(QtCore.QRect(42, 22, 551, 611))
        self.prof_win_shadow.setStyleSheet("background-color:rgb(0, 151, 221);\n"
                                           "border-radius: 50px;")
        self.prof_win_shadow.setText("")
        self.prof_win_shadow.setObjectName("prof_win_shadow")
        self.prof_win_username = QtWidgets.QLabel(self.profile_clicked)
        self.prof_win_username.setGeometry(QtCore.QRect(220, 70, 291, 40))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(20)
        self.prof_win_username.setFont(font)
        self.prof_win_username.setObjectName("prof_win_username")
        self.save = QtWidgets.QPushButton(self.profile_clicked)
        self.save.setGeometry(QtCore.QRect(130, 516, 371, 61))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(15)
        self.save.setFont(font)
        self.save.setStyleSheet("border-radius:22px;\n"
                                "background-color: rgb(85, 255, 0);\n"
                                "color: white;")
        self.save.setObjectName("save")
        self.save_shadow = QtWidgets.QLabel(self.profile_clicked)
        self.save_shadow.setGeometry(QtCore.QRect(134, 524, 371, 61))
        self.save_shadow.setStyleSheet("border-radius:22px;\n"
                                       "background-color: rgb(0, 121, 177);")
        self.save_shadow.setObjectName("save_shadow")
        self.border1 = QtWidgets.QLabel(self.profile_clicked)
        self.border1.setGeometry(QtCore.QRect(70, 190, 481, 81))
        self.border1.setStyleSheet("border-style: solid;\n"
                                   "border-width: 1px;\n"
                                   "border-radius: 25px;\n"
                                   "border-color:rgb(0, 151, 221);")
        self.border1.setText("")
        self.border1.setObjectName("border1")
        self.change_prof = QtWidgets.QPushButton(self.profile_clicked)
        self.change_prof.setGeometry(QtCore.QRect(90, 210, 201, 41))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(10)
        self.change_prof.setFont(font)
        self.change_prof.setStyleSheet("border-radius: 15px;\n"
                                       "background-color:rgb(0, 151, 221);\n"
                                       "color: white;")
        self.change_prof.setObjectName("change_prof")
        self.gender = QtWidgets.QComboBox(self.profile_clicked)
        self.gender.setGeometry(QtCore.QRect(340, 210, 181, 41))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.gender.setFont(font)
        self.gender.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.gender.setStyleSheet("border-radius: 15px;\n"
                                  "background-color:rgb(0, 151, 221);\n"
                                  "color: white;")
        self.gender.setEditable(False)
        self.gender.setIconSize(QtCore.QSize(1, 1))
        self.gender.setFrame(True)
        self.gender.setObjectName("gender")
        self.gender.addItem("")
        self.gender.addItem("")
        self.gender.addItem("")
        self.gender.addItem("")
        self.gem = QtWidgets.QLabel(self.profile_clicked)
        self.gem.setGeometry(QtCore.QRect(160, 337, 101, 91))
        self.gem.setText("")
        self.gem.setPixmap(QtGui.QPixmap("Images/dravina.png"))
        self.gem.setScaledContents(True)
        self.gem.setObjectName("gem")
        self.times = QtWidgets.QLabel(self.profile_clicked)
        self.times.setGeometry(QtCore.QRect(271, 356, 30, 51))
        font = QtGui.QFont()
        font.setFamily("Arial Rounded MT Bold")
        font.setPointSize(30)
        self.times.setFont(font)
        self.times.setStyleSheet("color:white;")
        self.times.setAlignment(QtCore.Qt.AlignCenter)
        self.times.setObjectName("times")
        self.score = QtWidgets.QLabel(self.profile_clicked)
        self.score.setGeometry(QtCore.QRect(315, 326, 191, 101))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(55)
        font.setBold(True)
        font.setWeight(75)
        self.score.setFont(font)
        self.score.setStyleSheet("color:white;")
        self.score.setObjectName("score")
        self.border2 = QtWidgets.QLabel(self.profile_clicked)
        self.border2.setGeometry(QtCore.QRect(70, 290, 481, 191))
        self.border2.setStyleSheet("border-style: solid;\n"
                                   "border-width: 1px;\n"
                                   "border-radius: 25px;\n"
                                   "border-color:rgb(0, 151, 221);")
        self.border2.setText("")
        self.border2.setObjectName("border2")
        self.confetti = QtWidgets.QLabel(self.profile_clicked)
        self.confetti.setGeometry(QtCore.QRect(30, 20, 551, 381))
        self.confetti.setStyleSheet("pixmap-opacity:0%;")
        self.confetti.setText("")
        self.confetti.setPixmap(QtGui.QPixmap("Images/confetti.png"))
        self.confetti.setScaledContents(True)
        self.confetti.setObjectName("confetti")
        self.close_btn = QtWidgets.QLabel(self.profile_clicked)
        self.close_btn.setGeometry(QtCore.QRect(520, 30, 40, 40))
        font = QtGui.QFont()
        font.setFamily("Arial Rounded MT Bold")
        font.setPointSize(10)
        self.close_btn.setFont(font)
        self.close_btn.setStyleSheet("border-radius: 20px;\n"
                                     "background-color:rgb(255, 85, 0);\n"
                                     "color:white;")
        self.close_btn.setAlignment(QtCore.Qt.AlignCenter)
        self.close_btn.setObjectName("close_btn")
        self.prof_win_shadow.raise_()
        self.prof_win.raise_()
        self.confetti.raise_()
        self.border1.raise_()
        self.times.raise_()
        self.save_shadow.raise_()
        self.profile_pic_shadow.raise_()
        self.score.raise_()
        self.save.raise_()
        self.profile_pic.raise_()
        self.prof_win_username.raise_()
        self.gender.raise_()
        self.gem.raise_()
        self.change_prof.raise_()
        self.border2.raise_()
        self.close_btn.raise_()
        self.back = QtWidgets.QWidget(self.centralwidget)
        self.back.setGeometry(QtCore.QRect(20, 150, 191, 91))
        self.back.setObjectName("back")
        self.back_back = QtWidgets.QLabel(self.back)
        self.back_back.setGeometry(QtCore.QRect(10, 0, 171, 71))
        font = QtGui.QFont()
        font.setFamily("Century Gothic")
        font.setPointSize(25)
        font.setBold(True)
        font.setWeight(75)
        self.back_back.setFont(font)
        self.back_back.setStyleSheet("color:white;")
        self.back_back.setAlignment(QtCore.Qt.AlignCenter)
        self.back_back.setObjectName("back_back")
        self.back_background = QtWidgets.QLabel(self.back)
        self.back_background.setGeometry(QtCore.QRect(0, 0, 181, 71))
        self.back_background.setStyleSheet("background-color:rgb(85, 255, 0);\n"
                                           "border-radius: 30px;")
        self.back_background.setText("")
        self.back_background.setObjectName("back_background")
        self.back_shadow = QtWidgets.QLabel(self.back)
        self.back_shadow.setGeometry(QtCore.QRect(4, 6, 181, 71))
        self.back_shadow.setStyleSheet("background-color:rgb(163, 162, 161);\n"
                                       "border-radius: 30px;")
        self.back_shadow.setText("")
        self.back_shadow.setObjectName("back_shadow")

        self.background1.raise_()
        self.logo.raise_()
        self.signin.raise_()
        self.signup.raise_()
        MainWindow.setCentralWidget(self.centralwidget)
        # ====================================================================================================================================
        self.novice.clicked.connect(self.openpage_novice)
        self.beginner.clicked.connect(self.openpage_intermediate)
        self.intermediate.clicked.connect(self.openpage_beginner)

        self.ham_novice.clicked.connect(self.ham_novoise_win)
        self.ham_beg.clicked.connect(self.ham_begginer_win)
        self.ham_int.clicked.connect(self.ham_intermediate_win)

        self.hamburger.mousePressEvent = self.ham_open_close
        self.close_btn.mousePressEvent = self.profile_edit_window_close
        self.profile.mousePressEvent = self.profile_edit_window
        self.level1_btn.mousePressEvent = self.level1_btn_func
        self.save.clicked.connect(self.save_profile)
        self.novice_sound.clicked.connect(self.playing_alpha)

        self.ham_shop.clicked.connect(self.men_at_work)
        self.level2_btn.mouseMoveEvent = self.men_at_work
        self.level3_btn.mouseMoveEvent = self.men_at_work
        self.change_prof.clicked.connect(self.men_at_work)

        self.ham_out.clicked.connect(lambda: os.execl(sys.executable, sys.executable, *sys.argv))
        self.ham_close.clicked.connect(self.open_website_and_close)
        self.ham_about.clicked.connect(lambda: webbrowser.open_new(self.website))

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def open_website_and_close(self):
        webbrowser.open_new(self.website)
        QtCore.QTimer.singleShot(500, lambda: MainWindow.close())

    def men_at_work(self):
        msg = QMessageBox()
        msg.setWindowTitle("Construction-Site")
        msg.setIcon(QMessageBox.Warning)
        msg.setText("This section of the application\nis under progress.")
        msg.setStandardButtons(QMessageBox.Ok)
        msg.exec_()

    def save_profile(self):

        items = []
        with open(r"Data/user.csv", 'r') as sd:
            reader = csv.reader(sd)
            for row in reader:
                items.append(row)

        for i in range(len(items)):
            if items[i][0] == self.user:
                items[i][1] = "Images/profile.png"
                items[i][2] = self.gender.currentText()

        with open(r"Data/user.csv", 'w', newline="") as csvfile:
            csvwriter = csv.writer(csvfile)
            csvwriter.writerows(items)
        sd.close()
        csvfile.close()

        msg = QMessageBox()
        msg.setWindowTitle("Saved")
        msg.setIcon(QMessageBox.Information)
        msg.setText("User-Data Updated")
        msg.setStandardButtons(QMessageBox.Ok)
        msg.exec_()

        self.profile_edit_window_close(MainWindow)

    def playing_alpha(self):
        if self.novice_question_number == 0:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 1:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 2:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 3:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 4:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 5:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 6:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 7:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 8:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 9:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 10:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 11:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 12:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 13:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 14:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 15:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 16:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 17:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 18:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 19:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 20:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 21:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 22:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 23:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 24:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 25:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 26:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 27:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 28:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 29:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 30:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 31:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 32:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 33:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 34:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 35:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 36:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 37:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 38:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 39:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 40:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 41:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

        elif self.novice_question_number == 42:
            alpha = sa.WaveObject.from_wave_file(
                r"Sounds/alpha_sounds/" + str(self.novice_question_number + 1) + ".wav")
            alpha.play().wait_done()

    def next_ques_novice(self):

        if self.novice_question_number < 44:
            if self.opt1_rad.isChecked() and (
                    self.question_data[self.novice_question_number][5] == self.opt1_rad.text()):
                msg = QMessageBox()
                msg.setWindowTitle("Congratulations")
                msg.setIcon(QMessageBox.Information)
                msg.setText("Correct Answer!")
                msg.setStandardButtons(QMessageBox.Ok)
                msg.exec_()
                self.novice_check.clicked.disconnect(self.next_ques_novice)

                self.novice_question_number += 1
                self.level1_btn_func(MainWindow)

            elif self.opt2_rad.isChecked() and (
                    self.question_data[self.novice_question_number][5] == self.opt2_rad.text()):
                msg = QMessageBox()
                msg.setWindowTitle("Congratulations")
                msg.setIcon(QMessageBox.Information)
                msg.setText("Correct Answer!")
                msg.setStandardButtons(QMessageBox.Ok)
                msg.exec_()
                self.novice_check.clicked.disconnect(self.next_ques_novice)

                self.novice_question_number += 1
                self.level1_btn_func(MainWindow)

            elif self.opt3_rad.isChecked() and (
                    self.question_data[self.novice_question_number][5] == self.opt3_rad.text()):
                msg = QMessageBox()
                msg.setWindowTitle("Congratulations")
                msg.setIcon(QMessageBox.Information)
                msg.setText("Correct Answer!")
                msg.setStandardButtons(QMessageBox.Ok)
                msg.exec_()
                self.novice_check.clicked.disconnect(self.next_ques_novice)

                self.novice_question_number += 1
                self.level1_btn_func(MainWindow)

            elif self.opt4_rad.isChecked() and (
                    self.question_data[self.novice_question_number][5] == self.opt4_rad.text()):
                msg = QMessageBox()
                msg.setWindowTitle("Congratulations")
                msg.setIcon(QMessageBox.Information)
                msg.setText("Correct Answer!")
                msg.setStandardButtons(QMessageBox.Ok)
                msg.exec_()
                self.novice_check.clicked.disconnect(self.next_ques_novice)

                self.novice_question_number += 1
                self.level1_btn_func(MainWindow)
            else:
                msg = QMessageBox()
                msg.setWindowTitle("Try Again")
                msg.setIcon(QMessageBox.Critical)
                msg.setText("Wrong Answer!")
                msg.setStandardButtons(QMessageBox.Ok)
                msg.exec_()
                self.novice_check.clicked.disconnect(self.next_ques_novice)

                self.level1_btn_func(MainWindow)
        else:

            checkpoint = []
            with open(r"Data/Checkpoints/" + self.user + ".csv", 'r') as rd:
                reader = csv.reader(rd)
                for row in reader:
                    checkpoint.append(row)

            if "novice-part-1" in checkpoint:

                msg = QMessageBox()
                msg.setWindowTitle("Congratulations")
                msg.setIcon(QMessageBox.Information)
                msg.setText("You completed this section")
                msg.setStandardButtons(QMessageBox.Ok)
                msg.exec_()
                self.ham_novoise_win()

            else:

                infile = open(r"Data/Checkpoints/" + self.user + ".csv", 'w', newline="")
                writer = csv.writer(infile)
                writer.writerow(["novice-part-1"])
                infile.close()

                items = []
                with open(r"Data/user.csv", 'r') as sd:
                    reader = csv.reader(sd)
                    for row in reader:
                        items.append(row)

                for i in range(len(items)):
                    if items[i][0] == self.user:
                        items[i][3] = int(items[i][3]) + 40

                sd.close()

                with open(r"Data/user.csv", 'w', newline="") as csvfile:
                    csvwriter = csv.writer(csvfile)
                    csvwriter.writerows(items)
                sd.close()
                csvfile.close()

                msg = QMessageBox()
                msg.setWindowTitle("Congratulations")
                msg.setIcon(QMessageBox.Information)
                msg.setText("You earned 40 Dravinas")
                msg.setStandardButtons(QMessageBox.Ok)
                msg.exec_()

                self.prog1_data.setGeometry(QtCore.QRect(230, 140, 811, 21))

                self.prog1_data.repaint()
                self.ham_novoise_win()

    def level1_btn_func(self, MainWindow):
        if self.cur == 1:
            self.subsection_1.lower()
            self.novice_questions.raise_()

            self.letter.setText(transliterate(self.question_data[self.novice_question_number][0], sanscript.ITRANS,
                                              sanscript.DEVANAGARI))
            self.letter.repaint()

            self.opt1_rad.setText(self.question_data[self.novice_question_number][1])
            self.opt2_rad.setText(self.question_data[self.novice_question_number][2])
            self.opt3_rad.setText(self.question_data[self.novice_question_number][3])
            self.opt4_rad.setText(self.question_data[self.novice_question_number][4])

            self.opt1_rad.setChecked(False)
            self.opt2_rad.setChecked(False)
            self.opt3_rad.setChecked(False)
            self.opt4_rad.setChecked(False)

            self.opt1_rad.repaint()
            self.opt2_rad.repaint()
            self.opt3_rad.repaint()
            self.opt4_rad.repaint()

            self.novice_check.clicked.connect(self.next_ques_novice)
        elif self.cur == 2 or self.cur == 3:
            self.men_at_work()

    def ham_novoise_win(self):
        click_sound()
        self.cur = 1
        self.hamwin.lower()
        self.hamwin_shadow.lower()
        self.hanburger_window.lower()
        self.shadow.lower()
        self.novice_questions.lower()
        self.label_novice.setStyleSheet("background-color: rgb(251, 195, 4);\n"
                                        "border-style: initial;\n"
                                        "border-width: 2px;\n"
                                        "border-radius: 30px;\n"
                                        "border-color: rgb(251, 195, 4);\n"
                                        "padding: 4px;\n"
                                        "color: white;")
        self.level_text_novice.raise_()
        self.level_text_beginner.lower()
        self.level_text_intermediate.lower()
        self.subsection_1.raise_()

        self.level1_heading.setText("Alphabet Training")
        self.level2_heading.setText("Matra Training")
        self.level3_heading.setText("Advanced Letter Training")

    def ham_begginer_win(self):
        click_sound()
        self.cur = 2
        self.hamwin.lower()
        self.hamwin_shadow.lower()
        self.hanburger_window.lower()
        self.shadow.lower()
        self.novice_questions.lower()
        self.label_novice.setStyleSheet("background-color: rgb(255, 87, 40);\n"
                                        "border-style: initial;\n"
                                        "border-width: 2px;\n"
                                        "border-radius: 30px;\n"
                                        "border-color: rgb(255, 87, 40);\n"
                                        "padding: 4px;\n"
                                        "color: white;")
        self.level_text_beginner.raise_()
        self.level_text_novice.lower()
        self.level_text_intermediate.lower()
        self.subsection_1.raise_()

        self.level1_heading.setText("Basic Rules")
        self.level2_heading.setText("Grammar")
        self.level3_heading.setText("Sentence Formation-1")

    def ham_intermediate_win(self):
        click_sound()
        self.cur = 3
        self.hamwin.lower()
        self.hamwin_shadow.lower()
        self.hanburger_window.lower()
        self.shadow.lower()
        self.novice_questions.lower()
        self.label_novice.setStyleSheet("background-color: rgb(150, 4, 62);\n"
                                        "border-style: initial;\n"
                                        "border-width: 2px;\n"
                                        "border-radius: 30px;\n"
                                        "border-color: rgb(251, 195, 4);\n"
                                        "padding: 4px;\n"
                                        "color: white;")
        self.level_text_intermediate.raise_()
        self.level_text_novice.lower()
        self.level_text_beginner.lower()
        self.subsection_1.raise_()

        self.level1_heading.setText("Vocabulary")
        self.level2_heading.setText("Sentence Formation-2")
        self.level3_heading.setText("Shlokas")

    def profile_edit_window(self, MainWindow):
        if self.ham == 1:
            self.ham = 0
            self.shadow.lower()
            self.hamwin_shadow.lower()
            self.hamwin.lower()
            self.hanburger_window.lower()
            self.profile_2.lower()
        self.shadow.raise_()
        self.profile_clicked.raise_()
        items = []
        with open(r"Data/user.csv", 'r') as sd:
            reader = csv.reader(sd)
            for row in reader:
                items.append(row)

        for i in range(len(items)):
            if items[i][0] == self.user:
                self.score_num = items[i][3]
                if items[i][2] == "Gender":
                    self.gender.setCurrentIndex(0)
                elif items[i][2] == "Male":
                    self.gender.setCurrentIndex(1)
                elif items[i][2] == "Female":
                    self.gender.setCurrentIndex(2)
                elif items[i][2] == "Others":
                    self.gender.setCurrentIndex(3)
        sd.close()
        self.score.setText(self.score_num)
        self.prof_win_username.setText(self.user)
        self.confetti.lower()

    def profile_edit_window_close(self, MainWindow):
        self.shadow.lower()
        self.profile_clicked.lower()

    def ham_back(self):
        self.header_shadow.raise_()
        self.header_2_shadow.raise_()
        self.footer_shadow.raise_()
        self.header_2.raise_()
        self.header.raise_()
        self.footer.raise_()
        self.logo_2.raise_()
        self.profile_shadow.raise_()
        self.profile.raise_()
        self.hamburger.raise_()

    def ham_open_close(self, MainWindow):

        self.Username.setText(self.user)
        if self.ham == 0:
            self.ham = 1
            self.shadow.raise_()
            self.hamwin_shadow.raise_()
            self.hamwin.raise_()
            self.hanburger_window.raise_()
            self.profile_2.raise_()
            self.ham_back()
        elif self.ham == 1:
            self.ham = 0
            self.shadow.lower()
            self.hamwin_shadow.lower()
            self.hamwin.lower()
            self.hanburger_window.lower()

    def raise_back(self):

        self.back.raise_()
        self.back_shadow.raise_()
        self.back_background.raise_()
        self.back_back.raise_()

    def openpage_novice(self):
        self.cur = 1
        self.openpage_main()
        self.novice_questions.lower()
        QtCore.QTimer.singleShot(500, lambda: self.label_shadow.raise_())
        QtCore.QTimer.singleShot(501, lambda: self.label_novice.raise_())
        self.label_novice.setStyleSheet("background-color: rgb(251, 195, 4);\n"
                                        "border-style: initial;\n"
                                        "border-width: 2px;\n"
                                        "border-radius: 30px;\n"
                                        "border-color: rgb(251, 195, 4);\n"
                                        "padding: 4px;\n"
                                        "color: white;")
        QtCore.QTimer.singleShot(502, lambda: self.level_text_novice.raise_())
        QtCore.QTimer.singleShot(503, lambda: self.subsection_1.raise_())

        QtCore.QTimer.singleShot(503, lambda: self.level1_heading.setText("Alphabet Training"))
        QtCore.QTimer.singleShot(503, lambda: self.level2_heading.setText("Matra Training"))
        QtCore.QTimer.singleShot(503, lambda: self.level3_heading.setText("Advanced Letter Training"))
        QtCore.QTimer.singleShot(503, lambda: self.level1.setPixmap(QtGui.QPixmap(r"Images/novice/1.png")))
        QtCore.QTimer.singleShot(503, lambda: self.level2.setPixmap(QtGui.QPixmap(r"Images/novice/2.png")))
        QtCore.QTimer.singleShot(503, lambda: self.level3.setPixmap(QtGui.QPixmap(r"Images/novice/3.png")))

    def openpage_intermediate(self):
        self.cur = 3
        self.openpage_main()
        self.novice_questions.lower()
        QtCore.QTimer.singleShot(500, lambda: self.label_shadow.raise_())
        QtCore.QTimer.singleShot(501, lambda: self.label_novice.raise_())
        self.label_novice.setStyleSheet("background-color: rgb(150, 4, 62);\n"
                                        "border-style: initial;\n"
                                        "border-width: 2px;\n"
                                        "border-radius: 30px;\n"
                                        "border-color: rgb(251, 195, 4);\n"
                                        "padding: 4px;\n"
                                        "color: white;")
        QtCore.QTimer.singleShot(502, lambda: self.level_text_intermediate.raise_())
        QtCore.QTimer.singleShot(503, lambda: self.subsection_1.raise_())

        QtCore.QTimer.singleShot(503, lambda: self.level1_heading.setText("Vocabulary"))
        QtCore.QTimer.singleShot(503, lambda: self.level2_heading.setText("Sentence Formation-2"))
        QtCore.QTimer.singleShot(503, lambda: self.level3_heading.setText("Shlokas"))

    def openpage_beginner(self):
        self.cur = 2
        self.openpage_main()
        self.novice_questions.lower()
        QtCore.QTimer.singleShot(500, lambda: self.label_shadow.raise_())
        QtCore.QTimer.singleShot(501, lambda: self.label_novice.raise_())
        self.label_novice.setStyleSheet("background-color: rgb(255, 87, 40);\n"
                                        "border-style: initial;\n"
                                        "border-width: 2px;\n"
                                        "border-radius: 30px;\n"
                                        "border-color: rgb(255, 87, 40);\n"
                                        "padding: 4px;\n"
                                        "color: white;")
        QtCore.QTimer.singleShot(502, lambda: self.level_text_beginner.raise_())
        QtCore.QTimer.singleShot(503, lambda: self.subsection_1.raise_())

        QtCore.QTimer.singleShot(503, lambda: self.level1_heading.setText("Basic Rules"))
        QtCore.QTimer.singleShot(503, lambda: self.level2_heading.setText("Grammar"))
        QtCore.QTimer.singleShot(503, lambda: self.level3_heading.setText("Sentence Formation-1"))

    def openpage_main(self):

        self.mainback.raise_()
        self.level_text_beginner.lower()
        self.level_text_novice.lower()
        self.level_text_intermediate.lower()
        self.ani_fade(self.mainback, 500)

        QtCore.QTimer.singleShot(500, lambda: self.header_shadow.raise_())
        QtCore.QTimer.singleShot(500, lambda: self.header_2_shadow.raise_())
        QtCore.QTimer.singleShot(500, lambda: self.footer_shadow.raise_())
        QtCore.QTimer.singleShot(500, lambda: self.footer.raise_())
        QtCore.QTimer.singleShot(500, lambda: self.header_2.raise_())
        QtCore.QTimer.singleShot(500, lambda: self.header.raise_())
        QtCore.QTimer.singleShot(500, lambda: self.logo_2.raise_())
        QtCore.QTimer.singleShot(500, lambda: self.hamburger.raise_())
        QtCore.QTimer.singleShot(500, lambda: self.profile_shadow.raise_())
        QtCore.QTimer.singleShot(500, lambda: self.profile.raise_())

    def ani_fade(self, widget, time):
        self.effect = QtWidgets.QGraphicsOpacityEffect()
        widget.setGraphicsEffect(self.effect)

        self.animation = QtCore.QPropertyAnimation(self.effect, b"opacity")
        self.animation.setEasingCurve(QtCore.QEasingCurve.InOutCubic)
        self.animation.setDuration(time)
        self.animation.setStartValue(0)
        self.animation.setEndValue(1)
        self.animation.start()

    def ani_moveup_logo(self, widget, time):

        self.effect = QtWidgets.QGraphicsOpacityEffect()
        widget.setGraphicsEffect(self.effect)

        self.animation = QtCore.QPropertyAnimation(self.effect, b"geometry")
        self.animation.setDuration(time)
        self.animation.setStartValue(QtCore.QRect(640, 540, 670, 271))
        self.animation.setEndValue(QtCore.QRect(640, 150, 670, 271))
        self.animation.start()

    def start_anew(self):
        self.signtext.lower()
        self.openpage_novice()

    def signup_(self):
        click_sound()
        self.signtext.raise_()
        self.signup.clicked.connect(self.signup_function)

    def signup_function(self):
        # on click of sign Up
        self.signtext.raise_()
        self.signup.setText("Sign Up")
        self.signup.repaint()

        items = []

        with open(r"Data/user.csv", 'r') as sd:
            reader = csv.reader(sd)
            for row in reader:
                items.append(row[0])
        if self.signtext.text() in items:
            msg = QMessageBox()
            msg.setWindowTitle("Checkpoint Found!")
            msg.setIcon(QMessageBox.Critical)
            msg.setText("\"" + self.signtext.text() + "\" already exists. Please Sign In")
            msg.setStandardButtons(QMessageBox.Ok)
            msg.exec_()
            # restart
            os.execl(sys.executable, sys.executable, *sys.argv)
        else:
            self.user = self.signtext.text()
            infile = open(r"Data/user.csv", 'a', newline="")
            writer = csv.writer(infile)
            writer.writerow([self.signtext.text(), "Images/profile.png", "Gender", 0])
            infile.close()
            with open(os.path.join(r"Data/Checkpoints", self.user + ".csv"), 'w') as fp:
                pass
            fp.close()
            self.start_anew()

    def sigin_function_1(self):
        # on first click of sign in
        click_sound()
        self.signtext.raise_()
        self.signup.setText("Sign In")
        self.signup.repaint()
        self.signup.pressed.connect(self.sigin_function_2)

    def sigin_function_2(self):
        # on second click of sign in
        click_sound()

        items = []

        with open(r"Data/user.csv", 'r') as sd:
            reader = csv.reader(sd)
            for row in reader:
                items.append(row[0])
        self.signtext.repaint()

        if self.signtext.text() in items:

            self.user = self.signtext.text()
            print(self.user)
            msg = QMessageBox()
            msg.setWindowTitle("Continue")
            msg.setIcon(QMessageBox.Information)
            msg.setText("Press OK to continue.")
            msg.setStandardButtons(QMessageBox.Ok)
            msg.exec_()
            self.start_anew()
        else:
            msg = QMessageBox()
            msg.setWindowTitle("Checkpoint Found!")
            msg.setIcon(QMessageBox.Critical)
            msg.setText("\"" + self.signtext.text() + "\" does not exist. Please create new account")
            msg.setStandardButtons(QMessageBox.Ok)
            msg.exec_()
            # restart
            os.execl(sys.executable, sys.executable, *sys.argv)

    def retranslateUi(self, MainWindow):

        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label_2.setText(_translate("MainWindow", "1"))
        self.signin.setText(_translate("MainWindow", "Sign In"))
        self.signup.setText(_translate("MainWindow", "Sign Up"))
        self.intermediate.setText(_translate("MainWindow", "BEGINNER"))
        self.beginner.setText(_translate("MainWindow", "INTERMEDIATE"))
        self.novice.setText(_translate("MainWindow", "NOVOICE"))
        self.welcome.setText(_translate("MainWindow", "swagatam"))
        self.Username.setText(_translate("MainWindow", "UserName"))
        self.ham_novice.setText(_translate("MainWindow", "Novice"))
        self.ham_beg.setText(_translate("MainWindow", "Beginner"))
        self.ham_int.setText(_translate("MainWindow", "Intermediate"))
        self.ham_shop.setText(_translate("MainWindow", "Shop"))
        self.ham_about.setText(_translate("MainWindow", "About Us"))
        self.ham_close.setText(_translate("MainWindow", "Close"))
        self.ham_out.setText(_translate("MainWindow", "Sign Out"))
        self.label_shadow.setText(_translate("MainWindow", "HELLO"))
        self.level_text_novice.setText(_translate("MainWindow", "N\nO\nV\nI\nC\nE"))
        self.level_text_beginner.setText(_translate("MainWindow", "B\nE\nG\nI\nN\nN\nE\nR"))
        self.level_text_intermediate.setText(_translate("MainWindow", "I\nN\nT\nE\nR\nM\nE\nD\nI\nA\nT\nE"))
        self.level1_heading.setText(_translate("MainWindow", "Heading"))
        self.level2_heading.setText(_translate("MainWindow", "Heading"))
        self.level3_heading.setText(_translate("MainWindow", "Heading"))
        self.prof_win_username.setText(_translate("MainWindow", "UserName"))
        self.save.setText(_translate("MainWindow", "SAVE"))
        self.save_shadow.setText(_translate("MainWindow", "TextLabel"))
        self.change_prof.setText(_translate("MainWindow", "Change Profile Picture"))
        self.gender.setItemText(0, _translate("MainWindow", "Gender"))
        self.gender.setItemText(1, _translate("MainWindow", "Male"))
        self.gender.setItemText(2, _translate("MainWindow", "Female"))
        self.gender.setItemText(3, _translate("MainWindow", "Others"))
        self.times.setText(_translate("MainWindow", "X"))
        self.score.setText(_translate("MainWindow", "999"))
        self.close_btn.setText(_translate("MainWindow", "X"))
        self.back_back.setText(_translate("MainWindow", "Back"))
        self.opt1_rad.setText(_translate("MainWindow", "opt"))
        self.opt2_rad.setText(_translate("MainWindow", "opt"))
        self.opt3_rad.setText(_translate("MainWindow", "opt"))
        self.opt4_rad.setText(_translate("MainWindow", "opt"))
        self.novice_check.setText(_translate("MainWindow", "Check Answer"))
        self.novice_sound.setText(_translate("MainWindow", "Sound"))
        self.letter.setText(_translate("MainWindow", "A"))
        self.label.setText(_translate("MainWindow", "What does the alphabet sound like?"))


if __name__ == "__main__":
    import sys

    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
