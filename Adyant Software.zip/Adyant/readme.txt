                              
	        _                 _   
	 ___  _| | _ _  ___  ___ | |_ 
	| .'|| . || | || .'||   ||  _|
	|__,||___||_  ||__,||_|_||_|  
	          |___|  



Steps to install adyant:

1. Python must be installed into the system.

2. 'pip install' all the python libraries mentioned below:

	PyQt5
	simpleaudio
	indic_transliteration
	webbrowser
	csv
	os

3. Run the Adyant.py script.

4. Enjoy learning Sanskrit !!!